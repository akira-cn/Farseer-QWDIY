P=/home/remember2015/htdocs/docgen
/usr/java/jre1.6.0_17/bin/java -cp $P/lib/js.jar org.mozilla.javascript.tools.shell.Main $P/lib/run.js config.json.jslint
