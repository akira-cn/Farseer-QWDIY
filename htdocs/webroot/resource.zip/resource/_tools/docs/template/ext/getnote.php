

Notes.classData = {
	"id" : "demo-docs",
	"iconCls" : "icon-docs",
	"text" : "Components's Demos",
	"singleClickExpand" : true,
	"expanded" : true,
	"children" : [],
};
Notes.icons = {
};

