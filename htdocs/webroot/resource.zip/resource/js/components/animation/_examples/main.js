(function() {
	var srcPath='../';

	document.write('<script type="text/javascript" src="' +srcPath+ 'qwrap-com.js"><\/script>');
	document.write('<script type="text/javascript" src="' +srcPath+ 'anim.js"></script>');
})();