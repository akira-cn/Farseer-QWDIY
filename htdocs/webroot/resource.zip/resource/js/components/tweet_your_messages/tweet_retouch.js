(function(){
	var TweetH = QW.TweetH;

	QW.NodeW.pluginHelper(TweetH, 'operator');
})();