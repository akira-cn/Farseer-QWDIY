(function() {

	describe('Browser', {
		'Browser Members': function() {
			value_of(QW.Browser).log();
		}
	});

}());