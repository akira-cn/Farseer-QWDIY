(function() {
	var HashsetH = QW.HashsetH;
	//JK begin-----
	describe('HashsetH', {
		'HashsetH Members': function() {
			value_of(HashsetH).log('');
		}


	});

}());