(function() {
	var EventH = QW.EventH;
	describe('EventH', {
		'EventH Members': function() {
			value_of(EventH).log('members');
		}
	});


}());