<?php defined('SYSPATH') or die('No direct script access.');

class Config_Database extends Kohana_Config_Database {}
