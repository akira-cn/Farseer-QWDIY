<?php defined('SYSPATH') or die('No direct script access.');

class Unittest_Runner extends Kohana_Unittest_Runner {}
