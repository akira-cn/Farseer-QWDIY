<?php defined('SYSPATH') or die('No direct script access.');

class Unittest_TestCase extends Kohana_Unittest_TestCase {}
