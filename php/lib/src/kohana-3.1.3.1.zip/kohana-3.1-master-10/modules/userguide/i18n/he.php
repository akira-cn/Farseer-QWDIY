<?php defined('SYSPATH') or die('No direct script access.');

return array
(
	'User Guide' => 'מדריך למשתמש'
);
