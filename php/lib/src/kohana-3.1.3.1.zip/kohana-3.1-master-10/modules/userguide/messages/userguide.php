<?php defined('SYSPATH') or die('No direct script access.');

return array(
	'translations' => array(
		'de-de' => 'Deutsch',
		'en-us' => 'English',
		'es-es' => 'Español',
		'zh-cn' => '简体中文',
		'ru-ru' => 'Русский',
		'fr-fr' => 'Français',
		'he-il' => 'עברית',
		'nl'	=> 'Nederlands',
	),
);
