<?php defined('SYSPATH') or die('No direct script access.');

class Config_File extends Kohana_Config_File {}