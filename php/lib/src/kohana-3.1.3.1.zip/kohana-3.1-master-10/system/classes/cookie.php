<?php defined('SYSPATH') or die('No direct script access.');

class Cookie extends Kohana_Cookie {}
