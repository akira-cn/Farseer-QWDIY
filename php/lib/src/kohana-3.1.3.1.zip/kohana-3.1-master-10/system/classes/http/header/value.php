<?php defined('SYSPATH') or die('No direct script access.');

class HTTP_Header_Value extends Kohana_HTTP_Header_Value {}