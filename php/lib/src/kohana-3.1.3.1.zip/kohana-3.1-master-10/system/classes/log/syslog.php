<?php defined('SYSPATH') or die('No direct script access.');

class Log_Syslog extends Kohana_Log_Syslog {}