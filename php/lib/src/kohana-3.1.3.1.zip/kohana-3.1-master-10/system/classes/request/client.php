<?php defined('SYSPATH') or die('No direct script access.');

abstract class Request_Client extends Kohana_Request_Client {}