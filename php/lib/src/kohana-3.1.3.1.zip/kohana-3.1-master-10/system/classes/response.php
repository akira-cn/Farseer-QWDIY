<?php defined('SYSPATH') or die('No direct script access.');

class Response extends Kohana_Response {}