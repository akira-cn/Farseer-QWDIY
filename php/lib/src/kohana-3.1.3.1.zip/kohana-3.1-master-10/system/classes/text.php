<?php defined('SYSPATH') or die('No direct script access.');

class Text extends Kohana_Text {}
