<http://kohanaframework.org/guide/about.mvc>

Discus the MVC pattern, as it pertains to Kohana.  Perhaps have an image, etc.